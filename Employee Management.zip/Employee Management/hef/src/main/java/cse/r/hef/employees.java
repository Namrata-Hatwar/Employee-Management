//package cse.r.hef;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//@Entity
//public class employees {
//	@Id
//	private int eid;
//	private String ename;
//	private String eaddress;
//	private String workrole;
//	private String email;
//	
//	public int getEid() {
//		return eid;
//	}
//
//	public void setEid(int eid) {
//		this.eid = eid;
//	}
//
//	public String getEname() {
//		return ename;
//	}
//
//	public void setEname(String ename) {
//		this.ename = ename;
//	}
//
//	public String getEaddress() {
//		return eaddress;
//	}
//
//	public void setEaddress(String eaddress) {
//		this.eaddress = eaddress;
//	}
//
//	public String getWorkrole() {
//		return workrole;
//	}
//
//	public void setWorkrole(String workrole) {
//		this.workrole = workrole;
//	}
//
//	public String getEmail() {
//		return email;
//	}
//
//	public void setEmail(String email) {
//		this.email = email;
//	}
//
//	@Override
//	public String toString() {
//		return "employees [eid=" + eid + ", ename=" + ename + ", eaddress=" + eaddress + ", workrole=" + workrole
//				+ ", email=" + email + "]";
//	}
//	
//	
//	
//
//}


